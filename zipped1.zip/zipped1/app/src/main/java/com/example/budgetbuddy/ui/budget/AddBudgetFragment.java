package com.example.budgetbuddy.ui.budget;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.budgetbuddy.databinding.FragmentAddBudgetBinding;
import com.example.budgetbuddy.databinding.FragmentHomeBinding;
import com.example.budgetbuddy.ui.home.HomeViewModel;

public class AddBudgetFragment extends Fragment {
    private FragmentAddBudgetBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        AddBudgetViewModel ViewModel =
                new ViewModelProvider(this).get(AddBudgetViewModel.class);

        binding = FragmentAddBudgetBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final TextView textView = binding.textAddBudget;
        ViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
